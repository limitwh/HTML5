$(function() {
	 $("complete input[type=checkbox]").attr("checked",true);
});