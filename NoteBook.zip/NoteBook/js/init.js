$(function() {
	h5.core.controller('.page', NotePadController);
});